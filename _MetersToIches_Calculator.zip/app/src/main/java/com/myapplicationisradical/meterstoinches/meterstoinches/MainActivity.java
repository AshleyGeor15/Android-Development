package com.myapplicationisradical.meterstoinches.meterstoinches;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText meters;
    private Button convert;
    private TextView results;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        meters = (EditText) findViewById(R.id.meterId);
        convert = (Button) findViewById(R.id.convertId);
        results = (TextView) findViewById(R.id.resultsId);

        convert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    double multiper =39.3701;
                    double result = 0.0;

                    double meterVal = Double.parseDouble(meters.getText().toString());
                    result = meterVal *multiper;

                    results.setText(Double.toString(result));

            }
        });
    }
}
